# 🫶🏾 ~𝔇𝔬𝔠🧑🏾‍⚕️𝔖~𝔞~𝔫~𝔡~𝔯~𝔞 🧑🏾‍⚕️✨ - Bot WhatsApp

Bot généré via Dev-Hackers Bot Builder.

## Installation
```bash
npm install
```

## Démarrage
```bash
npm start
```

Au premier démarrage :
1. Entrez votre numéro WhatsApp (format international, sans le +)
2. Vous recevrez un code à 8 chiffres sur WhatsApp
3. Entrez ce code dans le terminal

---
Créé par Dev-Hackers Bot Builder